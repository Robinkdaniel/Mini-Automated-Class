# RFID‑Based Door Lock System with User Identification
👨‍🎓 Final Year Project | Robin, Electronics & Communication Engineering  
🏫 [Your College Name], 2025

## Project Overview
This Arduino-based project allows authorized users to unlock a door using RFID cards. Each card's UID is matched; valid IDs unlock an electric solenoid lock briefly, and user identity is displayed on an LCD and logged to the Serial Monitor.

## Features
- RFID authentication
- Solenoid lock control (via transistor)
- LCD 16x2 (I2C) feedback
- Serial logging of UID
- Simple user identification via UID

## Hardware Components
| Component              | Quantity |
|------------------------|----------|
| Arduino Uno            | 1        |
| MFRC522 RFID Reader    | 1        |
| Solenoid Lock (12V)    | 1        |
| NPN Transistor (TIP120 or IRF540N) | 1 |
| 1N4007 Diode           | 1        |
| LCD 16x2 I2C Display   | 1        |
| External 12V Power Supply | 1     |
| Jumper Wires + Breadboard | -     |

## Wiring Diagram
- RFID (SPI): MOSI -> D11, MISO -> D12, SCK -> D13, SS -> D10, RST -> D9  
- LCD (I2C): SDA -> A4, SCL -> A5  
- Solenoid: Controlled by Arduino Pin 4 -> Transistor -> Solenoid -> GND  
- Flyback diode across solenoid terminals (1N4007)

## How It Works
1. Boot up the system.
2. LCD displays “Scan your card.”
3. Valid RFID card unlocks the solenoid for 3 seconds.
4. LCD shows “Access Granted,” then “Door Locked.”
5. Invalid cards are denied, with LCD and serial feedback.

## Author
Robin  
Electronics & Communication Engineering Student  
Final Year - 2025
